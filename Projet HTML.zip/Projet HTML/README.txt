﻿Nom des 5 étudiants :
	-	RAJARATNAM Sarujan
	-	MOHANASUNDARAM Ramanah
	-   	MAKHOUL Jean
	-	CHAPON Dylan
	-	HARRIGA Imane
________________________________________________________________________

Source des images (certaines images ont été traitées pour être adaptées au site):
	-	https://pixabay.com/fr/
	-	http://amapca.com/
	- 	https://amap-rpl.org/
	-       http://www.hallentours.com/
	-	http://macuisinejaune.canalblog.com/
________________________________________________________________________

Navigateur (compatibilité) :
	-	Google Chrome
________________________________________________________________________

Contenu du dossier :
	Fichiers textes :
		-	README.txt
		-	CHECKSUM.txt
		-	Document_de_suivi_-_2016-2017.pdf
		-	index.html
	
	Fichiers html :
	       adhérents.html
               amapiens.html
               article28-12-2016.html
               article29-12-2016.html
               article30-12-2016.html
               ateliers.html
               blog.html
               commandes.html
               conference.html
               contact.html
               evenements.html
               panier.html
               panierautomne.html
               panierete.html
               panierhiver.html
               panierprintemps.html
               rautomne.html
               recette.html
               reservation.html
               rete.html
               rhiver.html
               rprintemps.html
               visites.html
		
	Fichiers css :
	       adhérents.css
               article.css
               atelier.css
               blog.css
               contact.css
               index.css
               panier.css
               paniertype.css
               recette.css
               recette2.css
               reservation.css
		
	Images :
               1.png
               amapidf.png
               AMAP-logo.jpg
               atelierenfants.jpg
               autrement.jpg
               carotte.png
               carotte1.png
               carotte1-3.png
               commandes.jpg
               conference.jpg
               contrat_unique_adhesion_2017.pdf
               degustation.jpg
               exploitation-viande.jpg
               expo.jpg
               fbicon.png
               fleche.png
               googleicon.png
               header3.png
               iconesite.ico
               legumes.jpg
               pain.jpg
               panier.jpg
               panier.png
               panierautomne.jpg
               panierete.jpg
               panierhiver.jpg
               panierprintemps.jpg
               paniers.png
               photo28-12-2016.jpg
               photo29-12-2016.jpg
               photo30-12-2016.jpg
               r1.png
               r2.jpg
               r3.jpg
               r4.jpg
               recolte.jpg
               semer.jpg
               test.jpg
               test2.jpg
               test3.jpg
               testrecette1.jpg
               testrecette2.jpg
               testrecette3.jpg
               testrecette4.jpg
               to-eat-or-not-eat.png
               twittericon.png
               visite1.jpg
               visite2.jpg
               wall.jpg
________________________________________________________________________


