

Nom des 3 étudiants :
	-	RAJARATNAM Sarujan
	-	CHAPON Dylan
	-   	ABOUB Aymane
________________________________________________________________________

Enseignants:

	- DUB: Html
	- COULEAU: Communication
________________________________________________________________________

Source des images (certaines images ont été traitées pour être adaptées au site):
	-	https://www.google.com/imghp?hl=fr
	-	http://www.fermedegrignon.fr
________________________________________________________________________

Navigateur (compatibilité) :
	-	Google Chrome
________________________________________________________________________

Écran compatible:

	- Moniteur compatible 13" soit une résolution de 1440 x 900px
________________________________________________________________________

Ouverture du fichier index.html en premier qui fera activer une video automatique qui permettra d'accéder par la suite la page accueil.html


Contenu du dossier :
	
	Video:
		videoAcceuil.mp4

	Fichiers d'ouverture du dossier :
		-	README.txt
		-	Document_de_suivi_2017_2018.pdf
		-	index.html
		-	accueil.html
		-	index.css
		-	accueil.css
	
	Fichiers html :
		accueil.html
		adherents.html		adherents2.html		article06-01-2018.html		article28-12-2017.html		article29-12-2017.html		ateliers_a.html		ateliers_e.html		ateliers.html		blog.html		boutiques.html		contact.html		eve_spe.html		evenements.html
		index.html		presentation.html		visites.html
		
	Fichiers css :
		accueil.css
		article.css		ateliers.css		blog.css		boutiques.css		contact.css
		index.css		presentation.css		visites.css
		
	Images :
		adultes.jpg		atelierenfants.jpg		carotte.png		carotte1-3.png		carotte1.png		carte.png		catalogue_hiver_2018		comp.jpg		compost.jpg		compost2.jpg		ev.jpg		exploitation-viande.jpg		expo.jpg		fbicon.png
		ferme.jpg		ferme2.jpg		feux.jpg		fleche.png		fruits-hiver-noel-1.jpg		googleicon.png		head.jpg		Journee_thematiques_2018.png		Journees_thematiques_2018		l.png		lait_brique.png		logo.png		panier.png		pdf.png		photo28-12-2017.jpg		photo29-12-2017.jpg		R.png		recolte.jpg		Sans titre.png		sante.png		semer.jpg		twittericon.png		vache.jpg		vin.jpg		visites.png		wall.jpg
________________________________________________________________________



